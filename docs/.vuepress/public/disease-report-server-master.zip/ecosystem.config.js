// 参考链接：https://nuxtjs.org/faq/deployment-pm2/
module.exports = {
  apps: [
    {
      name: 'pdf_server',
      exec_mode: 'cluster',
      instances: 'max', // Or a number of instances
      script: 'npm',
      args: 'dev'
    }
  ]
}

