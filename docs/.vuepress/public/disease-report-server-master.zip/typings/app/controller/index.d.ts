// This file is created by egg-ts-helper@1.25.9
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportReport = require('../../../app/controller/report');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    report: ExportReport;
  }
}
