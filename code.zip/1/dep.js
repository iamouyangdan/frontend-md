class Dep {

  static target

  constructor() {
    // 存储更新的回调
    this.subs = []
  }

  addSub(sub) {
    this.subs.push(sub)
  }

  depend() {
    // 将target放入subs 在target里面处理
    if (Dep.target) {
      Dep.target.addDep(this)
    }
  }

  notify() {
    // 通知更新
    this.subs.forEach(item => {
      // 调用update
      item.update()
    })
  }
}
