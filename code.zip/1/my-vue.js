class MyVue {
  constructor(options) {
    this.options = options || {}
    // options绑定到this
    const optionsKey = Object.keys(this.options)
    optionsKey.forEach(key => {
      Object.defineProperty(this, key, {
        get() {
          return options[key]
        },
        set(val) {
          options[key] = val
        }
      })
    })
    // 添加一个$set
    this.$set = set
    // 初始化data
    this.initState()
    // 初始化method
    this.initMethods()
    // 简单的页面编译
    this.compileText()
  }
  initMethods() {
    const methods = this.methods
    if (methods) {
      // methods绑定到this
      const keys = Object.keys(methods)
      keys.forEach(key => {
        Object.defineProperty(this, key, {
          value: methods[key].bind(this)
        })
      })
    }
  }
  initState() {
    const data = this.data
    if (data) {
      // data绑定到this
      const keys = Object.keys(data)
      keys.forEach(key => {
        Object.defineProperty(this, key, {
          get() {
            return data[key]
          },
          set(val) {
            data[key] = val
          }
        })
      })
      // 观察data
      observe(data)
    }
  }
  compileText() {
    // 编译html
    new Compile(this)
  }
}

