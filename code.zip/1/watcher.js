class Watcher {
  constructor(vm, key, callback) {
    this.vm = vm
    this.key = key
    this.callback = callback
    // 记录当前值
    this.value = this.get()
  }
  addDep(dep) {
    // dep.subs放入当前watcher
    dep.addSub(this)
  }
  update() {
    // 通知回调
    const newValue = _.get(this.vm, this.key)
    const oldValue = this.value
    // 数组目前只做简单判断
    if (Array.isArray(newValue) && Array.isArray(oldValue)) {
      this.value = newValue
      // 触发 new Watcher时传入的回调
      this.callback.call(this.vm, newValue, oldValue)
    } else {
      if (newValue !== oldValue) {
        this.value = newValue
        // 触发 new Watcher时传入的回调
        this.callback.call(this.vm, newValue, oldValue)
      }
    }
  }
  get() {
    // Dep.target是当前watcher
    Dep.target = this
    // 触发一次获取属性值
    // 在属性值get里面因为有target
    // 会把当前watcher放入属性值的依赖
    const value = _.get(this.vm, this.key)
    // 存好就去掉标志
    Dep.target = null
    return value
  }
}
