const TextReg = /{{([^}}]+)}}/
const VmodelReg = /v-model="([^"]+)"/
const OnClickReg = /@click="([^"]+)"/
class Compile {
  constructor(vm) {
    this.vm = vm
    this.compileText()
  }
  compileText() {
    const el = this.vm.el
    // 获取el的元素
    const element = document.querySelector(el)
    if (!element) return
    // 遍历子元素  目前只有一层
    const children = element.childNodes
    children.forEach(node => {
      // 文本节点
      if (node.nodeType === 3) {
        const text = node.data
        if (TextReg.test(text)) {
          let textKey = (text.match(TextReg) || [])[1]
          if (textKey) {
            textKey = textKey.trim()
            const initValue = _.get(this.vm, textKey)
            this.updateText(node, initValue)
            // 创建观察者
            new Watcher(this.vm, textKey, (newValue, oldValue) => { 
              this.updateText(node, newValue);
            })
          }
        }
      } else if (node.nodeType === 1) {
        // 元素节点
        const innerText = node.innerText
        const outerHTML = node.outerHTML
        // 内容有 {{}}
        if (TextReg.test(innerText)) {
          let textKey = (innerText.match(TextReg) || [])[1]
          if (textKey) {
            textKey = textKey.trim()
            const initValue = _.get(this.vm, textKey)
            this.updateDomText(node, initValue)
            // 创建观察者
            new Watcher(this.vm, textKey, (newValue, oldValue) => { 
              this.updateDomText(node, newValue);
            })
          }
        } else if (node.nodeName === 'INPUT' && VmodelReg.test(outerHTML)) {
          // 输入框 v-model
          const vmodelKey = (outerHTML.match(VmodelReg) || [])[1]
          if (vmodelKey) {
            const vmodelValue = _.get(this.vm, vmodelKey)
            this.listenerInput(node, vmodelKey)
            this.updateInputValue(node, vmodelValue)
            // 创建观察者
            new Watcher(this.vm, vmodelKey, (newValue, oldValue) => { 
              this.updateInputValue(node, newValue);
            })
          }
        }

        // 点击事件
        if (OnClickReg.test(outerHTML)) {
          const methodKey = (outerHTML.match(OnClickReg) || [])[1]
          if (methodKey) {
            const method = this.vm[methodKey]
            this.listenerClick(node, method)
          }
        }
      }
    })
  }
  // 绑定点击事件
  listenerClick(node, method) {
    node.addEventListener('click', method, false)
  }
  // 输入事件
  listenerInput(node, vmodelKey) {
    node.addEventListener('input', (event) => {
      _.set(this.vm, vmodelKey, event.target.value)
    }, false)
  }
  // 更新输入框value
  updateInputValue(node, value) {
    node.value = value
  }
  // 更新文本
  updateText(node, initText) {
    if (!node.sourceData) {
      node.sourceData = node.data
    }
    node.data = node.sourceData.replace(TextReg, initText)
  }
  // 更新元素内容
  updateDomText(node, initText) {
    if (!node.sourceInnerText) {
      node.sourceInnerText = node.innerText
    }
    node.innerText = node.sourceInnerText.replace(TextReg, initText)
  }
}
