const isObject = function (value) {
  return typeof value === 'object' && value !== undefined && value !== null
}
class Observer {
  constructor(value) {
    this.value = value
    // 创建一个依赖
    this.dep = new Dep()
    // 绑定__ob__
    Object.defineProperty(value, '__ob__', {
      value: this
    })
    if (Array.isArray(value)) {
      // 数组 修改数组原型为修改过的
      this.protoAugment(value, arrayMethods)
      // 遍历数组
      this.observeArray(value)
    } else {
      // 对象
      this.walk(value)
    }
  }

  protoAugment(target, arrayMethods) {
    target.__proto__ = arrayMethods
  }
  
  observeArray(array) {
    for (let i = 0, l = array.length; i < l; i++) {
      observe(array[i])
    }
  }

  walk(obj) {
    const keys = Object.keys(obj)
    // 遍历属性
    keys.forEach(key => {
      defineReactive(obj, key)
    })
  }
}
function defineReactive(obj, key, val) {
  // 每个属性创建一个依赖
  const dep = new Dep()

  let value = obj[key] || val
  // 判断属性值 如果是对象或者数组在观察
  let childOb = observe(value)
  Object.defineProperty(obj, key, {
    enumerable: true,
    configurable: true,
    get() {
      // 如果依赖有target
      if (Dep.target) {
        // 收集依赖
        dep.depend()
        if (childOb) {
          childOb.dep.depend()
        }
      }
      return value
    },
    set(newValue) {
      if (newValue === value) {
        return
      }
      value = newValue
      childOb = observe(newValue)
      // 通知更新
      dep.notify()
    }
  })
}
function set(target, key, val) {
  if (key in target && !(key in Object.prototype)) {
    target[key] = val
    return val
  }
  const ob = target.__ob__
  if (!ob) {
    target[key] = val
    return val
  }
  // 定义属性双向绑定
  defineReactive(ob.value, key, val)
  // 通知一下更新
  ob.dep.notify()
  return val
}
function observe(value) {
  if (!isObject(value)) {
    return
  }
  let ob
  if (value.__ob__) {
    ob = value.__ob__
  } else if (typeof value === 'object' || Array.isArray(value)) {
    ob = new Observer(value)
  }
  return ob
}
