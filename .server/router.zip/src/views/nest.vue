<!--
 * @file: 嵌套路由
-->
<template>
  <div>
    <div>嵌套路由</div>
    <div>以下内容是嵌套进来的路由</div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
