<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <div>
      时间: {{ time }}
    </div>
    <div>
      keepalive: {{ $route.meta.keepAlive }}
    </div>
    <HelloWorld msg="Welcome to Your Vue.js App"/>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  },
  data () {
    return {
      time: ''
    }
  },
  mounted () {
    this.time = new Date().getTime()
    console.log(this.$route)
    console.log(this.$route.meta)
  }
}
</script>
