import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    alias: '/home', // 路由别名
    component: Home,
    meta: {
      title: '首页',
      keepAlive: false // 控制是否需要 keepAlive
    }
  },
  // 路由重定向
  // {
  //   path: '/home',
  //   redirect: to => {
  //     return {
  //       path: '/',
  //       query: { from: 'home' }
  //     }
  //   }
  // },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  },
  {
    path: '/about/:id',
    name: 'About',
    component: () => import('../views/About.vue')
  },
  // 嵌套路由
  {
    path: '/nest/:id',
    name: 'nest',
    component: () => import('../views/nest.vue'),
    children: [
      {
        path: 'about',
        component: () => import('../views/About.vue')
      }
    ]
  }
  // 所有没定义路由的页面跳转到 Home 页
  // {
  //   path: '/:pathMatch(.*)*',
  //   name: 'NotFound',
  //   component: Home
  // }
]

const router = new VueRouter({
  routes,
  mode: 'hash'
})

export default router
