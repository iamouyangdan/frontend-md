import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false

// 前置守卫
router.beforeEach((to, from, next) => {
  // console.info('from', from)
  // TODO 可以用于权限判断 根据用户权限改变目标页面
  next()
})

// 后置钩子
router.afterEach((to, from, failure) => {
  // TODO 可以用于一些添加一些页面提示, 或者做一些统一的页面跳转操作
  // 如: 携带某参数跳转页面后弹出对应的提示
  // console.info('after', from)
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
