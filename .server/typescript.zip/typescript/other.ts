// 类型断言 将一个联合类型断言为其中一个类型
interface Cat {
  name: string;
  run(): void;
}
interface Fish {
  name: string;
  swim(): void;
}

function isFish(animal: Cat | Fish) {
  // 如果是cat则没有 swim 方法, 编译会报错. 此处需要使用类型断言
  // if (typeof animal.swim === 'function') {
  //   return true;
  // }
  if (typeof (animal as Fish).swim === 'function') {
    return true;
  }
  return false;
}