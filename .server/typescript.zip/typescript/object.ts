/** 对象的类型
 * 赋值的时候，变量的形状必须和接口的形状保持一致，不允许增多或者减少属性，需要增加或减少属性请用以下属性：
 * 1、可选属性，在属性后面加? 标识属性是可选的
 * 2、任意属性
 * 一旦定义了任意属性，那么确定属性和可选属性的类型都必须是它的类型的子集
 * 如：使用 [propName: string] 定义了任意属性取 string|number 类型的值，那么可选属性和确定属性必须是 string|number 的子集,若新增属性 isPublic: Boolean, 则报错.
 * 
 * 3、只读属性， 在属性前加 readonly 标识只读属性
 */
 interface product {
  readonly id?: number;
  name: string;
  price: number;
  desc?: string;
  [propName: string]: string|number;
  // isPublic: boolean;
}

let obj: product = {
  name: '一件商品',
  price: 100,
  sku: '红色'
}
obj.name = '一件商品的新名字'
console.log('对象类型: ', obj)

/** 数组类型
* 1、[类型 + 方括号] 表示法
* 2、数组泛型
* 3、用接口表示数组（不推荐）
*/

let arr: number[] = [1, 2, 3]
let arr2: (number | string)[] = [1, 2, 3, '4']
//  let arr: number[] = [1, 2, 3, '4'] // 报错
