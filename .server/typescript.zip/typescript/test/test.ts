function sayHello(person: string) {
    return 'Hello, ' + person;
}

let user = 'Tom';
console.log(sayHello(user));

// 数据类型
// 在 TypeScript 中, 用: 指定变量类型(编译时会进行检查, 如果发现有错误则会编译报错, 在赋值过程中不会改变类型)
const b: boolean = false
const s: string = 'Str'
const n: number = 123
const nu: null = null
const u: undefined = undefined

console.log('若变量赋值不是对应类型的值, 则编译时会报错。如：把数字赋值给String类型的变量')

// 任意类型: 变量如果在声明的时候，未指定其类型，那么它会被识别为任意值类型：
let a: any = '1'
a = 1

let a1
a1 = 'str'
a1 = 1

/* 类型推论: 如果没有明确的指定类型, TypeScript根据规则推断出一个类型
注意: 在 TypeScript 中以下写法不等价
写法一:
let x
x = 'str'
写法二:
let x = 'str'

写法一的 x 是 any 类型, 写法二的 x 是 string 类型
*/

// 联合类型
let connect: Boolean|number = 1
console.log('connect', connect)
connect = true
console.log('connect', connect)

/** 对象的类型
 * 赋值的时候，变量的形状必须和接口的形状保持一致，不允许增多或者减少属性，需要增加或减少属性请用以下属性：
 * 1、可选属性，在属性后面加? 标识属性是可选的
 * 2、任意属性
 * 一旦定义了任意属性，那么确定属性和可选属性的类型都必须是它的类型的子集
 * 如：使用 [propName: string] 定义了任意属性取 string|number 类型的值，那么可选属性和确定属性必须是 string|number 的子集,若新增属性 isPublic: Boolean, 则报错.
 * 
 * 3、只读属性， 在属性前加 readonly 标识只读属性
 */
interface product {
    readonly id?: number;
    name: string;
    price: number;
    desc?: string;
    [propName: string]: string|number;
    // isPublic: boolean;
}

let obj: product = {
    name: '一件商品',
    price: 100,
    sku: '红色'
}
obj.name = '一件商品的新名字'
console.log('对象类型: ', obj)