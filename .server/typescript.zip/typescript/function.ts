
// 函数类型
// 1、函数声明
function sum(x: number, y: number): number {
  return x + y;
}
// 注意: 输入多余的（或者少于要求的）参数，是不被允许的
// sum(1)
console.log('求和函数: ', sum(1, 2))

// 2、用接口定义函数的形状
interface multiplication {
  (x: number, y: number, z?: number): number;
}
let mult: multiplication
mult = function(x: number, y: number, z?: number) {
  if (z || z === 0) {
      return x * y * z;
  }
  return x * y;

}
console.log('求积函数:', mult(1, 2))
console.log('求积函数:', mult(1, 2, 3))

// 3、重载
function arraySum(x: number): number;
function arraySum(x: number[]): number;
function arraySum(x: (number | number[])): number {
  if (typeof x === 'number') {
      return x
  } else {
      let sum: number = 0
      x.forEach(item => {
          sum += item
      })
      return sum
  }
}
console.log('重载求和函数:', arraySum(1))
console.log('重载求和函数:', arraySum([1, 2, 3]))