export default (context, inject) => {
    context.$http = async () => {

    };
}