<template>
  <div class="ui-main">
    <div class="ui-content">123</div>
  </div>
</template>

<script>
export default {
  data() {
    return {

    };
  },
  async asyncData({ $http }) {

  },
  mounted() {

  },
  methods: {}
}
</script>

<style scoped lang="less">
.ui-content {
  width: 6.98rem;
  height: 3rem;
  margin: 0 auto;
  background-color: green;
  border: 1px solid red;
}
</style>